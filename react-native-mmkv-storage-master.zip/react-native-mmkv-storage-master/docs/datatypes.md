# Data Types

The following javascript data types are supported

<div
style="
display:flex;
flex-direction:row;
width:80%;
flex-wrap:wrap;
">

<div
style="
width:100px;
height:100px;
background-color:lightgreen;
border-radius:10px;
color:green;
justify-content:center;
text-align:center;
display:flex;
align-items: center;
flex-direction: column;
margin:20px;
">
  <p>
  Strings<br/>
  ""
  </p>
</div>

<div
style="
width:100px;
height:100px;
background-color:lightgreen;
border-radius:10px;
color:green;
justify-content:center;
text-align:center;
display:flex;
align-items: center;
flex-direction: column;
margin:20px;
">
  <p>
  Boolean<br/>
  true/false
  </p>
</div>

<div
style="
width:100px;
height:100px;
background-color:lightgreen;
border-radius:10px;
color:green;
justify-content:center;
text-align:center;
display:flex;
margin:20px;
align-items: center;
flex-direction: column;
">
  <p>
  Numbers<br/>
  123
  </p>
</div>

<div
style="
width:100px;
height:100px;
background-color:lightgreen;
border-radius:10px;
color:green;
margin:20px;
justify-content:center;
text-align:center;
display:flex;
align-items: center;
flex-direction: column;
">
  <p>
  Objects<br/>
  {}
  </p>
</div>

<div
style="
width:100px;
height:100px;
background-color:lightgreen;
border-radius:10px;
color:green;
justify-content:center;
text-align:center;
display:flex;
margin:20px;
align-items: center;
flex-direction: column;
">
  <p>
  Arrays<br/>
  []
  </p>
</div>

</div>


The Map data type is **not** supported.
