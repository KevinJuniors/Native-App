# react-native-mmkv-storage <small>0.6.11</small>


> An ultra fast(0.0002s read/write), small & encrypted mobile key-value storage framework for React Native written in C++ using JSI

Ultra fast | Encrypted | Easy to use

[GitHub](https://github.com/ammarahm-ed/react-native-mmkv-storage)
[Getting Started](#react-native-mmkv-storage)



![color](#000000) 