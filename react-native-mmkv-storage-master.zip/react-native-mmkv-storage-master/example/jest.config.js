module.exports = {
  preset: 'react-native',
  setupFiles: ['../jest/mmkvJestSetup.js'],
  transformIgnorePatterns: ['/../\\/'],
};
